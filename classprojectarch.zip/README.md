# TwitterProjectICS412
This is a small data mining project for class using our own-sourced data. The project looks to find bot participation in the 2022 MN Gov election. 
